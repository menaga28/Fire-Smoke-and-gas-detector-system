<?php
//Example - MySQLi
//Step 1. Connect to the database.
//Step 2. Handle connection errors
// including the database connection file
$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error());

// to select the targeted database
mysqli_select_db($conn, "firefighter") or die(mysqli_error());


$query = "SELECT * FROM user";

//to run sql query in database
$result = mysqli_query($conn, $query) or die(mysqli_error());


if(isset($_POST['update']))
{	
	//The mysqli_real_escape_string() function escapes special characters in a string for use in an SQL statement.
	$uID = mysqli_real_escape_string($conn, $_POST['uID']);	
	$Name = mysqli_real_escape_string($conn, $_POST['Name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
    $PhoneNumber = mysqli_real_escape_string($conn, $_POST['PhoneNumber']);	
	
	// checking empty fields
	if(empty($Name) || empty($email) || empty($PhoneNumber)) {	
			
		if(empty($Name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>email field is empty.</font><br/>";
		}
		
		if(empty($PhoneNumber)) {
			echo "<font color='red'>PhoneNumber field is empty.</font><br/>";
		}		
	} else {	
		//Step 3. Execute the SQL query.
		//updating the table
		$result = mysqli_query($conn, "UPDATE user SET Name='$Name',email='$email',PhoneNumber='$PhoneNumber' WHERE uID=$uID");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: manageUser.php");
		
		//Step 5: Freeing Resources and Closing Connection using mysqli
		mysqli_close($conn);
	}
}
?>
<?php
//getting id from url
$uID = $_GET['uID'];

//selecting data associated with this particular id
$result = mysqli_query($conn, "SELECT * FROM user WHERE uID=$uID");

while($res = mysqli_fetch_array($result))
{
	$Name = $res['Name'];
	$email = $res['email'];
	$PhoneNumber = $res['PhoneNumber'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Loading Template CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/bootstrap-icons.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style-magnific-popup.css" rel="stylesheet">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Open+Sans:ital@0;1&display=swap" rel="stylesheet">

    <!-- Font Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/in.php">User Detail</a>
     <a href="http://localhost/menaga/iofrm-by-brandio/Template/RealTimeMonitor.html">Real-Time Monitor </a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/manageUser.php">Manage User</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>
  <!-- <a href="#about">About</a> -->
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
	
	<br/><br/>
	<!-- The updated form data entered by user is sent using the HTTP POST method -->
	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="Name" value="<?php echo $Name;?>"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo $email;?>"></td>
			</tr>
			<tr> 
				<td>PhoneNumber</td>
				<td><input type="text" name="PhoneNumber" value="<?php echo $PhoneNumber;?>"></td>
			</tr>
			<tr>
				<!-- send hidden data, id using GET method -->
				<td><input type="hidden" name="uID" value=<?php echo $_GET['uID'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
