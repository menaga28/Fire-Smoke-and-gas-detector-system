<?php
include ("db_conn.php");

session_start();

	if(isset($_POST['submit']))
		{
	$email = $_POST['email'];
	$password=$_POST['password'];

	$query = "SELECT * FROM register WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn,$query);
	
	if (mysqli_num_rows ($result) == 1)
	{
		echo "<script>alert ('success')</script>";
		
		$role = "SELECT *FROM register WHERE email='$email' AND password='$password'";
		$roles = mysqli_query($conn,$role);
		$row  = mysqli_fetch_array($roles);
		
			if ($row['role'] == "Admin")
			{
				$_SESSION['admin'] = $email;
				header("location: index.php");
			}
			else if ($row['role'] == "User")
			{
				$_SESSION['user'] = $email;
				header("location: user.php");
			}
		}
		else
		{
			echo "<script>alert('invalid')</script>";
		}
	
}
?>