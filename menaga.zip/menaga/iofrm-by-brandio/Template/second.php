<?php
session_start();

$admin = $_SESSION['admin'];
echo "second";
?>


<!DOCTYPE html>
<html>
<head>
	<title>second</title>
</head>
<body>
</body>
</html>