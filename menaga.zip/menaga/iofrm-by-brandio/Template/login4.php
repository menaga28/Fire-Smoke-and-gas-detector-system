<?php
include ("db_conn.php");

session_start();

if(isset($_POST['login']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];

	$query = "SELECT * FROM register WHERE username='$username' AND password='$password'";
	$result = mysqli_query($connect,$query);
	
	if (mysqli_num_rows ($result) == 1)
	{
		echo "<script>alert ('success')</script>";
		
		$role = "SELECT *FROM register WHERE username='$username' AND password='$password'";
		$roles = mysqli_query($connect,$role);
		$row  = mysqli_fetch_array($roles);
		
			if ($row['role'] == "Admin")
			{
				$_SESSION['admin'] = $username;
				header("location: second.php");
			}
			else if ($row['role'] == "User")
			{
				$_SESSION['user'] = $username;
				header("location: first.php");
			}
		}
		else
		{
			echo "<script>alert('invalid')</script>";
		}
	
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iofrm</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-theme4.css">
</head>
<body>
    <div class="form-body" class="container-fluid">
        <div class="website-logo">
            <a href="">
                <div class="logo">
                    <img class="logo-size" src="" alt="">
                </div>
            </a>
        </div>
        <div class="row">
            <div class="img-holder">
                <div class="bg"></div>
                <div class="info-holder">
                    <img src="images/graphic1.svg" alt="">
                </div>
            </div>
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3>Login to Fire Fighter Page</h3>
                        <p>Access to the most powerfull website of the Fire Fighter.</p>
                        <div class="page-links">
                            <a href="login4.php" class="active">Login</a><a href="register4.php">Register</a>
                        </div>
                        <form  action= "loginconn.php" method="post"> 
                            <input class="form-control" type="email" name="email" placeholder="E-mail Address" required>
                            <input class="form-control" type="password" name="password" placeholder="Password" required>
							

                            <div class="form-button">
                                 <button id="submit" type="submit" value="Submit" name="submit" onclick="add()"class="ibtn">Login</button>
                            </div>
                        </form>
                        <div class="other-links">
                            <span>Or login with</span><a href="#">Facebook</a><a href="#">Google</a><a href="#">Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>
