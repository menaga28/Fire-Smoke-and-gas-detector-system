<?php
	//$conn = mysqli_connect("localhost", "root", "", "firefighter");

	//if(!$conn)
	//{
	//	die(" Connection Error ");
	//}
	include ("db_conn.php");
	session_start();

	$admin = $_SESSION['admin'];

	if(isset($_POST['Update']))
	{
		// $Admin_ID = $_GET['GetAdmin_ID'];
    	// $Admin_Name = $_GET['Admin_Name'];
		$Admin_Name = $_POST['Admin_Name'];
		$Admin_Email = $_POST['Admin_Email'];
		$Admin_Password = $_POST['Admin_Password'];
		// $Admin_Contact = $_POST['Admin_Contact'];

		$query = "UPDATE register
		SET name = '$Admin_Name',  password = '$Admin_Password'
		WHERE email = '$admin'";

		$result = mysqli_query($conn, $query);

		if($result)
		{
      echo "<script type='text/javascript'>alert('Succesfully Updated!!');
      window.location = 'in.php';
      </script>";
	    header("location:in.php?restartSession=true");
		}
		else
		{
			die("Error updating user data !  ".$conn->error);
		}
	}

	else
	{
		header("location:index.php");
	}
