
<?php

  //mysqli_connect('localhost','root','');
 // mysqli_select_db("firefighter");
  $connect = mysqli_connect("localhost","root","","firefighter");

  ?>