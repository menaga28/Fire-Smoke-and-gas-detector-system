<?php
$uID = $_GET['uID'];
$link = mysqli_connect ('localhost', 'root', '', 'firefighter');
if (!$link)
{
	die ("Could not connect: ".mysqli_connect_error());
}
else
{
	$queryDelete = "DELETE FROM user WHERE uID = '".$uID."'";
	$resultDelete = mysqli_query($link,$queryDelete);
	if (!$resultDelete)
	{
		die ("Error: ".mysqli_error($link));
		}		
	else {
		header("Location: manageUser.php");
	}
}
?>