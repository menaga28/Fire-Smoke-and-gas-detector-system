<?php  

$sname = "localhost";
$uname = "root";
$password = "";

$db_name = "firefighter";

//$conn = mysqli_connect($sname, $uname, $password, $db_name);
$conn = mysqli_connect("localhost", "root", "", "firefighter");

if (!$conn) {
	echo "Connection Failed!";
	exit();
}