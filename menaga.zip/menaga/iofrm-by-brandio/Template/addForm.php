<?php
include ("db_conn.php");

session_start();


	if(isset($_POST['submit']))
	{
		//$Admin_Name = $_POST['name'];
		//$Admin_Email = $_POST['email'];
		//$Admin_Password = $_POST['password'];
		
		$name = $_POST['name'];
		$email= $_POST['email'];
		$password = $_POST['password'];
		$role = $_POST['role'];
		
		
		$query = "INSERT INTO register (name,email,password,role)
					VALUES ('$name','$email','$password','$role')";

		$result = mysqli_query($conn, $query);

		if($result)
		{
			echo "<script type='text/javascript'>alert('Succesfully Registered!!')</script>";
			header("Location:login4.php");
			
		}
		else
		{
			echo "<script> alert ('Failed to register')</script>";
			header("Location:register4.php");
		}
	}

?>
