

<?php

  include("connection.php");

   if (isset($_POST['submit']))
{
	$name = $_POST['name'];
	$email= $_POST['email'];
	$password = $_POST['password'];
	$role = $_POST['role'];
	
	$query = "INSERT INTO register(username,email,password,role) VALUES ('$name',
	'$email','$password','$role')";
		
	$result = mysqli_query($connect,$query);
	
	if ($result) {
		
		echo "<script> alert ('success') </script>";
	}
	else
	{
		echo "<script> alert ('failed to signup')</script>";
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iofrm</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-theme4.css">
</head>
<body>
    <div class="form-body" class="container-fluid">
        <div class="website-logo">
            <a href="index.html">
                <div class="logo">
                    <img class="logo-size" src="" alt="">
                </div>
            </a>
        </div>
        <div class="row">
            <div class="img-holder">
                <div class="bg"></div>
                <div class="info-holder">
                    <img src="images/graphic1.svg" alt="">
                </div>
            </div>
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3>Login to Fire Fighter Page</h3>
                        <p>Access to the most powerfull website of the Fire Fighter.</p>
                        <div class="page-links">
                            <a href="login4.php">Login</a><a href="register4.php" class="active">Register</a>
                        </div>
                        <form action="addForm.php" method="POST">
                            <input class="form-control" type="text" name="name" placeholder="Full Name" required>
                            <input class="form-control" type="email" name="email" placeholder="E-mail Address" required>
                            <input class="form-control" type="password" name="password" placeholder="Password" required>
                            
							<select name="role" class="form-control">
								<option value=""> Select Your Role</option>
								<option value="Admin"> Admin</option>
								<option value="User"> User</option>
							</select>
							
							
							<div class="form-button">
                                <button id="submit" type="submit" value="Submit" name="submit" onclick="add()"class="ibtn">Register</button>
                            </div>
                        </form>
                        <div class="other-links">
                            <span>Or register with</span><a href="#">Facebook</a><a href="#">Google</a><a href="#">Linkedin</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>
