<?php
//Example - MySQLi
//Step 1. Connect to the database.
//Step 2. Handle connection errors
//including the database connection file
$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error());

// to select the targeted database
mysqli_select_db($conn, "firefighter") or die(mysqli_error());


$query = "SELECT * FROM admin";

//to run sql query in database
$result = mysqli_query($conn, $query) or die(mysqli_error());


//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
//3. Execute the SQL query.
$result = mysqli_query($conn, "SELECT * FROM user ORDER BY uID DESC"); // using mysqli_query instead
?>

<html>
<head>	
	<title>Manage User</title>
</head>

<body>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Loading Template CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/bootstrap-icons.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style-magnific-popup.css" rel="stylesheet">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Open+Sans:ital@0;1&display=swap" rel="stylesheet">

    <!-- Font Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">

<a href="http://localhost/menaga/iofrm-by-brandio/Template/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/in.php">User Detail</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/RealTimeMonitor.html">Real-Time Monitor </a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/manageUser.php">Manage User</a>
     <a href="http://localhost:8081/">Receive Emergency notification</a>
   <a href="http://localhost/menaga/iofrm-by-brandio/Template/attend.php">Daily Report</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/report.php">View Report</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>

  
  
  <!-- <a href="#about">About</a> -->
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
 <br> 


<a href="add.php" class="btn btn-primary" role="button">Add User</a><br/><br/>

	<table class="table">

	<tr bgcolor='#CCCCCC'>
		<td>Name</td>
		<td>Email</td>
		<td>PhoneNumber</td>
		<td>Update</td>
		
	</tr>
	<?php 
		//Step 4. Process the results from add.php (insert new data)
		//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
		while($res = mysqli_fetch_array($result)) { 		
			echo "<tr>";
			echo "<td>".$res['Name']."</td>";
			echo "<td>".$res['email']."</td>";
			echo "<td>".$res['PhoneNumber']."</td>";	
			echo "<td><a href=\"edit.php?uID=$res[uID]\">Edit</a> | <a href=\"delete.php?uID=$res[uID]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
			echo "</tr>";
		}
		
		//Step 5: Freeing Resources and Closing Connection using mysqli
		mysqli_close($conn);
	?>
	</table>
</body>
</html