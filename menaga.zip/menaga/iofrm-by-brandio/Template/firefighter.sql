-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2021 at 07:38 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `firefighter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_Name` varchar(255) NOT NULL,
  `Admin_Email` varchar(255) NOT NULL,
  `Admin_Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_Name`, `Admin_Email`, `Admin_Password`) VALUES
('Venkedhswaran', 'menagamurugiah28@gmail.com', '12345'),
('menaga murugiah', 'menagamurugiah28@gmail.com', '11111'),
('tasha', 'tasha@gmail.com', '33333'),
('Patrick a/l luis', 'menagamurugiah@gmail.com', '22222'),
('menaga murugiah', 'meenu@gmail.com', '2809'),
('melena vishnu', 'www.@gmail.com', '2512'),
('tasha', 'tasha@gmail.com', '12345'),
('meera', 'meera@gmail.com', '11111'),
('meena', 'menagamurugiah@gmail.com', '123456'),
('menagamurugiah', 'menagamurugiah@gmail.com', '12345'),
('sumathe', 'sumathe@gmail.com', '12345'),
('alia', 'alia@gmail.com', '123456'),
('jhgfds', 'menagamurugiah@gmail.com', '123456'),
('melena vishnu', 'menagamurugiah@gmail.com', '12345'),
('mmmm', 'menagamurugiah@gmail.com', '1234'),
('menaga', 'meelena@gmail.com', '6666'),
('menaga', 'meelena@gmail.com', '6666'),
('menaga', 'meelena@gmail.com', '6666'),
('patrick', 'patrick@gmail.com', '5564'),
('tasha', 'tasha@gmail.com', '1111'),
('meleena', 'meelena@gmail.com', '6666'),
('tasha', 'tasha@gmail.com', '12345'),
('menaga', 'meelena@gmail.com', '6666'),
('Menaga Murugiah', 'meenu@gmail.com', '2222'),
('amma', 'amma@gmail.com', '11111');

-- --------------------------------------------------------

--
-- Table structure for table `adminupdate`
--

CREATE TABLE `adminupdate` (
  `Admin_Name` varchar(255) NOT NULL,
  `Admin_Email` varchar(255) NOT NULL,
  `Admin_Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminupdate`
--

INSERT INTO `adminupdate` (`Admin_Name`, `Admin_Email`, `Admin_Password`) VALUES
('Menaga Murugiah', 'menagamurugiah28@gmail.com', '909091');

-- --------------------------------------------------------

--
-- Table structure for table `attend`
--

CREATE TABLE `attend` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attend`
--

INSERT INTO `attend` (`id`, `name`, `email`, `time`) VALUES
(1, 'Ali', 'ali@gmail.com', '2021-08-27 06:34:57'),
(2, 'aiman', 'aiman@gmail.com', '2021-08-27 06:35:01'),
(3, 'abu', 'abu@gmail.com', '2021-08-27 06:35:05'),
(4, 'aina', 'aina@gmail.com', '2021-08-27 06:38:22'),
(5, 'dev', 'dev@gmail.com', '2021-08-27 07:52:33'),
(6, 'tiru', 'tiru@gmail.com', '2021-08-27 09:30:18'),
(7, 'myna', 'myna@gmail.com', '2021-08-27 12:08:41'),
(8, 'nazifa', 'nazifa@gmail.com', '2021-08-29 12:11:47'),
(9, 'Menaga Murugiah', 'menagamurugiah28@gmail.com', '2021-09-01 01:58:26');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `password`, `role`, `date`) VALUES
(1, 'Ali', 'ali@gmail.com', '123456', 'Admin', '2021-08-25 14:51:43'),
(3, 'abu', 'abu@gmail.com', '147258', 'User', '2021-08-25 18:14:29'),
(4, 'pavi', 'pavi@gmail.com', '111222', 'User', '2021-08-25 18:32:19'),
(5, 'aiman', 'aiman@gmail.com', '123123', 'Admin', '2021-08-26 06:40:34'),
(6, 'mayan', 'mayan@gmail.com', '147147', 'User', '2021-08-26 18:08:38'),
(7, 'axxd', 'axx@gmail.com', '111111', 'Admin', '2021-08-26 18:08:17'),
(8, 'aina', 'aina@gmail.com', '888888', 'Admin', '2021-08-26 14:04:27'),
(9, 'abc', 'abc@gmail.com', '363636', 'Admin', '2021-08-26 18:07:30'),
(10, 'dev', 'dev@gmail.com', '585858', 'User', '2021-08-26 18:08:53'),
(11, 'tiru', 'tiru@gmail.com', '323232', 'Admin', '2021-08-26 18:07:37'),
(12, 'amza', 'amza@gmail.com', '989898', 'User', '2021-08-26 18:07:41'),
(13, 'amit', 'amit@gmail.com', '454545', 'Admin', '2021-08-27 09:22:29'),
(14, 'myna', 'myna@gmail.com', '172839', 'Admin', '2021-08-27 12:08:08'),
(15, 'nazifa', 'nazifa@gmail.com', '321654', 'User', '2021-08-29 12:11:29'),
(16, 'patrick', 'luis@gmail.com', '2809', 'Admin', '2021-09-01 01:25:40'),
(17, 'meenu', 'mee@gmail.com', '1111', 'User', '2021-09-01 02:00:25'),
(18, 'hahauser', 'tu@yahoo.com', '1234567', 'Admin', '2021-09-11 17:31:53');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uID` int(255) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `PhoneNumber` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uID`, `Name`, `email`, `password`, `PhoneNumber`) VALUES
(1, 'mena', 'menagaurugiah28@gmail.com', 'september28', '0162054569'),
(4, 'sumathe', 'sumathe@gmail.com', '', '0166091067'),
(5, 'Heswary', 'his123@gmail.com', '', '012 3456789'),
(8, 'Patrick luis', 'patrickluis@gmail.com', '', '01112345343'),
(11, 'ckeena', 'ckeena@gmail.com', '', '011212678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attend`
--
ALTER TABLE `attend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attend`
--
ALTER TABLE `attend`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
