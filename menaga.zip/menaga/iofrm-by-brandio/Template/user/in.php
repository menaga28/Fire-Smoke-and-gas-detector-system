 <?php
include ("db_conn.php");
session_start();

$admin = $_SESSION['user'];
//echo $admin;
$query = "SELECT * FROM register WHERE email='$admin'";
$roles = mysqli_query($conn,$query);
$row  = mysqli_fetch_array($roles);
    
//session_start();
//$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error());

// to select the targeted database
//mysqli_select_db($conn, "firefighter") or die(mysqli_error());


//$query = "SELECT * FROM admin";
//$query = "SELECT * FROM register";

//to run sql query in database
//$result = mysqli_query($conn, $query) or die(mysqli_error());

//Check wether the query was successful or not
//if(isset($result)) {
//if(mysqli_num_rows($result) == 1) {

  //Login Succesfull
  //session_regenerate_id();
  //$member = mysqli_fetch_assoc($result);
  
 // $_SESSION['Admin_ID'] = $member['Admin_ID'];
 // $_SESSION['Admin_Name'] = $member['Admin_Name'];
 // $_SESSION['Admin_Email'] = $member['Admin_Email'];
  //$_SESSION['Admin_Password'] = $member['Admin_Password'];
 // $_SESSION['Admin_Contact'] = $member['Admin_Contact'];
 // $_SESSION['STATUS'] = true;
 // session_write_close();
 
 // header("location: index.php");
 // exit();
 
 
 
//
//
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

  <div class="topnav" id="myTopnav">
    
	<
	
 <a href="http://localhost/menaga/iofrm-by-brandio/Template/user/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/user/in.php">User Detail</a>
  <a href="http://localhost:8081/">Receive Emergency Notification</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/user/attend.php">Daily Report</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>

	
    <!-- <a href="#about">About</a> -->
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
  </div>

  <div style="padding-left:16px">
    <h2>User Detail</h2>
    <!-- <p>Resize the browser window to see how it works.</p> -->
  </div>

  <script>
  function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }
  </script>

<h2 style="text-align:center">User Profile Card</h2>

<div class="card">
  <img src="images/2.png" alt="User" style="width:100%">
  <h1><?php echo $row['name'] ?></h1>
  <p></p>
  <p class="title"><?php echo $row['email'] ?></p>
  <!-- <p class="title">< ?php echo $_SESSION['Admin_Password'] ?></p> -->
  <a href="update.php?>" class="w3-btn w3-black">Update</a>
</div>

</body>
</html>
