
<?php

   include("connection1.php");


   if (isset($_POST['submit']))
{
	$name = $_POST['name'];
	$email= $_POST['email'];
	//$password = $_POST['password'];
	//$role = $_POST['role'];
	
	$query = "INSERT INTO attendance(name,email) VALUES ('$name','$email')";
		
	$result = mysqli_query($connect,$query);
	
	if ($result) {
		
		echo "<script> alert ('Attended') </script>";
	}
	else
	{
		echo "<script> alert ('failed to note attendance')</script>";
	}
}
?>


<!DOCTYPE html>
<html>
<head>
<title>Database</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #4CAF50;
  text-align: center;
  cursor: pointer;
 width: 10%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
  <body>

  <div class="topnav" id="myTopnav">
  
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/user/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/user/in.php">User Detail</a>
    <a href="http://localhost:8081/">Receive Emergency Notification</a>
	<a href="http://localhost/menaga/iofrm-by-brandio/Template/user/attend.php">Daily Report</a>
	<a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>
	
	
</div>
</body>
<html lang="en">
<!--<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iofrm</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="css/iofrm-theme4.css">
</head>-->
<body>
   <!--<div class="form-body" class="container-fluid">
        <div class="website-logo">
            <a href="index.html">
                <div class="logo">
                    <img class="logo-size" src="" alt="">
                </div>
            </a>
        </div>
        <div class="row">
            <div class="img-holder">
                <div class="bg"></div>
                <div class="info-holder">
                    <img src="images/graphic1.svg" alt="">
                </div>
            </div>-->
            <!--<div class="form-holder"><center>
                <div class="form-content">
                    <div class="form-items">
                        <h3><center>Attendence</h3>
                        <p>Access to the most powerfull website of the Fire Fighter.</p>
                        <div class="page-links">
                            <a href="login4.php">Login</a><a href="register4.php" class="active">Register</a>
                        </div>-->
						<!--<table align="center" border="1px" style="width:500px; line-height:25px;">-->
						<br>
						<br>
						<br>
						<br>
						<h3><center>Attendance</h3>
						<br>
                        <form action="addform1.php" method="POST"><center>
						
							<input class="form-control" type="text" name="name" placeholder="Full Name" required>
						   <br>
						   <br>
                            <input class="form-control" type="email" name="email" placeholder="E-mail Address" required>
							<br>
							<br>
							<div class="form-button">
                                <button id="submit" type="submit" value="Submit" name="submit" onclick="add()"class="ibtn">Submit</button>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>
