<?php

include("db_conn.php");
session_start();

$admin = $_SESSION['admin'];
//echo $admin;
$query = "SELECT * FROM register WHERE email='$admin'";
$roles = mysqli_query($conn, $query);
$row  = mysqli_fetch_array($roles);

///	$conn = mysqli_connect("localhost", "root", "", "firefighter");

//	if(!$conn)
//	{
//		die(" Connection Error ");
//	}

//	$Admin_Name = $_GET['GetAdmin'];
//	$query = "SELECT * FROM admin
//				WHERE Admin_Name='".$Admin_Name."'";

//	$result = mysqli_query($conn, $query);

//	while($row=mysqli_fetch_assoc($result))
//	{
// $Admin_ID = $row['Admin_ID'];
//		$Admin_Name = $row['Admin_Name'];
//		$Admin_Email = $row['Admin_Email'];
//		$Admin_Password = $row['Admin_Password'];
// $Admin_Contact = $row['Admin_Contact'];
//	}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <script>
    function goBack() {
      header("location:javascript://history.go(-1)");
    }
  </script>
  <title>Admin List</title>

  <style>
    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    .topnav {
      overflow: hidden;
      background-color: #333;
    }

    .topnav a {
      float: left;
      display: block;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    .topnav a:hover {
      background-color: #ddd;
      color: black;
    }

    .topnav a.active {
      background-color: #04AA6D;
      color: white;
    }

    .topnav .icon {
      display: none;
    }

    @media screen and (max-width: 600px) {
      .topnav a:not(:first-child) {
        display: none;
      }

      .topnav a.icon {
        float: right;
        display: block;
      }
    }

    @media screen and (max-width: 600px) {
      .topnav.responsive {
        position: relative;
      }

      .topnav.responsive .icon {
        position: absolute;
        right: 0;
        top: 0;
      }

      .topnav.responsive a {
        float: none;
        display: block;
        text-align: left;
      }
    }

    input[type=text],
    input[type=number],
    input[type=date] {
      width: 99%;
      padding: 10px;
    }

    input[type=submit] {
      background-color: #00aea6;
      border: 3px solid black;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
      border-radius: 2px;
    }

    table,
    tr,
    th,
    td {
      border: 3px solid black;
      border-collapse: collapse;
      padding: 5px;
      text-align: left;
      background: white;
    }

    th {
      background: #00aea6;
      color: black;
      width: 20%;
    }

    td {
      width: 80%;
    }
  </style>
</head>

<body>

  <div class="topnav" id="myTopnav">

    <a href="http://localhost/menaga/iofrm-by-brandio/Template/index.php">Home</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/in.php" class="active">User Detail</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/RealTimeMonitor.html">Real-Time Monitor </a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/manageUser.php">Manage User</a>
	<a href="http://localhost:8081/">Receive Emergency notification</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/attend.php">View Report</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/report.php">Daily Report</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>
    <!-- <a href="#about">About</a> -->
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
  <br>
  <br>
  <!-- Update -->
  <form action="updateForm.php" method="POST">
    <input type="hidden" name="action" value="update">
    <center>
      <table>
        <tr>
          <th>Admin Email</th>
          <td><input type="text" disabled id="Admin_Email" name="Admin_Email" value="<?php echo $row['email'] ?>"></td>
          <i style="color: blue">You cannot edit your email as it is verified in the database</i>
        </tr>

        <tr>
          <th>Admin Name</th>
          <td><input type="text" id="Admin_Name" name="Admin_Name" value="<?php echo $row['name'] ?>"></td>
        </tr>



        <tr>
          <th>Admin Password</th>
          <td><input type="text" id="Admin_Password" name="Admin_Password" value="<?php echo $row['password'] ?>"></td>
        </tr>



      </table><br>

      <input type="submit" id="Update" name="Update" value="Update">
      <input type="submit" id="Back" name="Back" value="Back" onclick="goBack()">






    </center>
  </form>

</body>

</html>

<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>