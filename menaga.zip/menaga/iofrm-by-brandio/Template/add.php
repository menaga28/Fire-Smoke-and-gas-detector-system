
<?php
//Example - MySQLi procedural
//Step 1. Connect to the database.
//Step 2. Handle connection errors
//including the database connection file
$conn = mysqli_connect("localhost", "root", "") or die(mysqli_error());

// to select the targeted database
mysqli_select_db($conn, "firefighter") or die(mysqli_error());


$query = "SELECT * FROM admin";

//to run sql query in database
$result = mysqli_query($conn, $query) or die(mysqli_error());


if(isset($_POST['Submit'])) {	
	//The mysqli_real_escape_string() function escapes special characters in a string for use in an SQL statement.

	$Name = mysqli_real_escape_string($conn, $_POST['Name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
    $PhoneNumber = mysqli_real_escape_string($conn, $_POST['PhoneNumber']);	
	
		
	// checking empty fields
	if(empty($Name) || empty($email) || empty($PhoneNumber)) {	
			
		if(empty($Name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($email)) {
			echo "<font color='red'>email field is empty.</font><br/>";
		}
		
		if(empty($PhoneNumber)) {
			echo "<font color='red'>PhoneNumber field is empty.</font><br/>";
		}		
	
	} else { 
		// if all the fields are filled (not empty) 
		
		//Step 3. Execute the SQL query.	
		//insert data to database	
		$result = mysqli_query($conn, "INSERT INTO user(Name,email,PhoneNumber) VALUES('$Name','$email','$PhoneNumber')");
		
		//Step 4. Process the results.
		//display success message & the new data can be viewed on index.php
		header("Location:manageUser.php");
	
		//Step 5: Freeing Resources and Closing Connection using mysqli
		mysqli_close($conn);
	}
}
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Loading Template CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/bootstrap-icons.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style-magnific-popup.css" rel="stylesheet">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Open+Sans:ital@0;1&display=swap" rel="stylesheet">

    <!-- Font Favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">
<style>
body {

  background-color:rgba(0, 128, 0, 0.3);

  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/in.php">User Detail</a>
    <a href="http://localhost/menaga/iofrm-by-brandio/Template/RealTimeMonitor.html">Real-Time Monitor </a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/manageUser.php">Manage User</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>
  <!-- <a href="#about">About</a> -->
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

<head>


	<title>Add Data</title>
</head>

<body>
	
	<br/><br/>

<title>Add Data</title>

	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="Name"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr> 
				<td>PhoneNumber</td>
				<td><input type="text" name="PhoneNumber"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
</body>
</html>


</body>
</html>