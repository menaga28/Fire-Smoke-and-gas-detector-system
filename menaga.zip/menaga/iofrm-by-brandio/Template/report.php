<!DOCTYPE html>
<html>
<head>
<title>Database</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
  <body>

  <div class="topnav" id="myTopnav">
  
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/index.php" class="active">Home</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/in.php">User Detail</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/RealTimeMonitor.html">Real-Time Monitor </a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/manageUser.php">Manage User</a>
  <a href="http://localhost:8081/">Receive Emergency notification</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/attend.php">Daily Report</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/report.php">View Report</a>
  <a href="http://localhost/menaga/iofrm-by-brandio/Template/logout.php">Logout</a>

	
	
</div>
</body>
<br>

<body>
<h3><center>Daily Report</center></h3>
<br>
 <table align="center" border="1px" style="width:800px; line-height:45px;">
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>

<th>Role</th>
<th>Date&Time</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "firefighter");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT id, name, email,role,date FROM register";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
	echo "<tr><td>" . $row["id"]. 
	"</td><td>" . $row["name"] . 
	"</td><td>" . $row["email"] .
	
	"</td><td>" . $row["role"] .
	"</td><td>". $row["date"]. "</td></tr>";
	
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
</body>
</html>